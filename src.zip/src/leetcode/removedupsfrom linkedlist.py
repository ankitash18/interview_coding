# Definition for singly-linked list.
class ListNode:
     def __init__(self, val=0, next=None):
        self.val = val
        self.next = next


def deleteDuplicates( head):
    if (head is None):
        return
    else:
        currentNode = head
        visited = set([currentNode.val])
        while currentNode.next:
            if currentNode.next.val in visited:
                currentNode.next = currentNode.next.next
            else:
                visited.add(currentNode.next.val)
                currentNode = currentNode.next
        return head
