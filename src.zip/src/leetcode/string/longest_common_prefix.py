#Given a set of strings, find the longest common prefix. Input  : {“geeksforgeeks”, “geeks”, “geek”, “geezer”}

Input  =['geeksforgeeks','geeks','geez']
Input1  =['apple','ape','april']
Output = "gee"

def checkcommon(s1,s2):
    l1 = len(s1)
    l2 = len(s2)
    i= 0
    j = 0
    prefix = ""
    while i < l1 and j <l2:
        if s1[i] == s2[j]:
            prefix += s1[i]
        else:
            break
        i+=1
        j +=1
    return prefix



def find_longest_prefix(arr):

    prefix = arr[0]
    n = len(arr)

    for i in range(1,n):
        #print(arr[i])
        #print(f"..prefix...{prefix}")
        if prefix is not None:
            prefix = checkcommon(prefix,arr[i])


    return prefix

ans1 = find_longest_prefix(Input)
print(ans1)

#wohtout using extar space
s = ['flower', 'flow', 'flight']
import sys

def find_prefix(s):
    len_of_arr = len(s)
    len_of_char = sys.maxsize
    for i in s:
        len_of_char = min(len_of_char,len(i))

    print(len_of_char)
    print(len_of_arr)
    prefix = ""

    for i in range(len_of_char):
        c = s[0][i]
        flag = True
        print(f"..c ..{c}")
        for j in range(1,len_of_arr):
            print(f"..s[j][i]....{s[j][i]}")
            if (c != s[j][i]):
                flag = False
                break
        if flag:
            prefix += c
    return  prefix

ans = find_prefix(s)
#print(ans)
