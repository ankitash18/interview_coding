"""
Given a string, find the minimum number of deletions required to convert it into a palindrome.
The idea is to use recursion to solve this problem. The idea is to compare the last character of the string X[i…j] with its first character. There are two possibilities:

If the string’s last character is the same as the first character, no deletion is needed, and we recur for the remaining substring X[i+1, j-1].
If the last character of the string is different from the first character, return one plus the minimum of the two values we get by:
Deleting the last character and recursing for the remaining substring X[i, j-1].
Deleting the first character and recursing for the remaining substring X[i+1, j].
"""

def minDeletions(X, i, j):
    # base condition
    if i >= j:
        return 0

    # if the last character of the string is the same as the first character
    if X[i] == X[j]:
        return minDeletions(X, i + 1, j - 1)
    # otherwise, if the last character of the string is different from the
    # first character

    # 1. Remove the last character and recur for the remaining substring
    # 2. Remove the first character and recur for the remaining substring

    # return 1 (for remove operation) + minimum of the two values
    return min(minDeletions(X, i, j - 1), minDeletions(X, i + 1, j)) +1


def find(X):
    n=  len(X)
    print('The minimum number of deletions required is', minDeletions(X, 0, n - 1))


X = 'ACBCDBAA'
find(X)