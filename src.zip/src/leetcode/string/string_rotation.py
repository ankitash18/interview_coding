"""
Given two strings, the task is to find if a string can be obtained by rotating another string two places.
Input: string1 = “amazon”, string2 = “azonam”
Output: Yes
Explanation: Rotating string1 by 2 places in anti-clockwise gives the string2.
"""
"""
The idea is to Rotate the String1 in both clockwise and ant-clockwise directions. Then if this rotated string is equal to String2.
abcd
"""
def rotatestr(str1,str2,k):
    if len(str1) !=len(str2):
        return False
    #initlaise empty string for clock wise
    str_clock=""
    #for anti clock wise
    str_anti=""
    l = len(str1)

    str_clock += str_clock+str1[k:]+str1[0:k]
    print(str_clock)

    str_anti += str_anti+str1[l-k:]+str1[0:l-k]
    print(str_anti)
    if str2 == str_clock or str2 == str_anti:
        return True
    else:
        return False

str1 = "amazon"
str2 = "azonam"
str3 = "geeks"
str4 = "eksge"


print(rotatestr(str3,str4,2))