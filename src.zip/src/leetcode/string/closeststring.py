"""
Given a list of words followed by two words, the task to find the minimum distance between the given two words in the list of words

S = {"geeks", "for", "geeks", "contribute",
     "practice"}
word1 = "geeks"
word2 = "practice"
Output: 2
Explanation: Minimum distance between the
words "geeks" and "practice" is 2
"""
import sys


def findshortdist(s,word1,word2):
    distance = sys.maxsize
    k = 0
    l = 0
    count = 0
    if word1 == word2:
        return 0
    else:
        for j in range(0,len(s)):
            if s[j] == word1:
                k=j
                count +=1
            if s[j] == word2:
                l=j
                count +=1
            if count >=2:
                tempdis = abs(l-k)
                distance = min(tempdis,distance)
    return distance

str = ["geeks", "for", "geeks", "contribute",
     "practice"]
word1 = "geeks"
word2 = "practice"

s = ["the", "quick", "brown", "fox",
     "quick"]
word11 = "the"
word21 = "fox"
print(findshortdist(s,word11,word21))

