def isdivisible7(num):
    if int(num) %7 ==0:
        return 1
    else:
        return 0

num = "8955795758"
print(isdivisible7(num))