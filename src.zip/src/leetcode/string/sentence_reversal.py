#sentence reversal
#loop throhg list,,push the word to stack and pop it out ot new string

#reverse word first...using range and loop...not ot use inbuilt reversed or slice
import re
#direct by slicing ..word = word[::-1]
def rev_word(word):
    length = len(word)

    sen = word.split(" ")
    print(sen)

    length = len(sen)

    word = [sen[ch] for ch in range(length-1,-1,-1)]
    temp = []
   # print(f"..word..{word}")

    #or.........this way.............
    for words in range(length-1,-1,-1):
        print(words)
        temp.append(sen[words])

    word1 = " ".join(temp)

    print(word1)


    word = " ".join(word)
    print(word)

word = "this is the best"
rev_word(word)

def sentence_reversal(words):
    pass




word = "this is the best"

listtr = word.split(' ')

new = " ".join(listtr)
#print(new)