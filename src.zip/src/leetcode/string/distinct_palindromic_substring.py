"""
Suppose we have a string; we have to count how many palindromic substrings present in this string.
"""

def countSubstrings(s):
    counter = 0
    set = []
    for i in range(len(s)):
        for j in range(i + 1, len(s)+1):
            temp = s[i:j]
            print(f",,,,curr.....{temp}")
            print(f",,,,currrev.....{temp[::-1]}")
            if temp == temp[::-1]:
                if temp not in set:
                    set.append(temp)
                    counter += 1
                print(f"counter....{counter}")
    return counter


print(countSubstrings("geek"))