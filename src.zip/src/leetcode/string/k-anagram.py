"""
Check if two strings are k-anagrams or not
Two strings are called K-anagrams if both of the below conditions are true.
1. Both have same number of characters.
2. Two strings can become anagram by changing at most K characters in a string.
Input:
str1 = "fodr", str2="gork"
k = 2
Output:
1
Explanation: Can change fd to gk
"""

def kanagram(str1,str2,k):
    l1 = len(str1)
    l2 = len(str2)
    l3 = []
    if l1 != l2:
        return False

    str1 = list(str1)
    str1.sort()
    str2 = list(str2)
    str2.sort()
    print(str1)
    print(str2)
    for i in range(l1):
        if str1[i] != str2[i]:
            l3.append(str2[i])

    if len(l3) <= k:
        return True
    else :
        return False





str1 = "fodr"
str2 = "gork"
k = 2
ans = kanagram(str1,str2,k)
print(ans)