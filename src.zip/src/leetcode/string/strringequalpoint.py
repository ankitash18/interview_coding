"""
Equal point in a string of brackets
Given a string of brackets, the task is to find an index k which decides the number of opening brackets is equal to the number of closing brackets.
The string must be consists of only opening and closing brackets i.e. ‘(‘ and ‘)’.

An equal point is an index such that the number of opening brackets before it is equal to the number of closing brackets from and after.
Input: str = “(())))(“
Output:   4
Explanation: After index 4, string splits into (()) and ))(. The number of opening brackets in the first part is equal to the number of closing brackets in the second part.
"""

def findindex(str):
    l = len(str)
    open =[0]*(l+1)
    close = [0] * (l + 1)
    index = -1

    open[0] = 0
    close[l] = 0
    if str[0] =="(":
        open[1] = 1
    if str[l-1] ==")":
        close[l-1]= 1

    for i  in range(1,l):
        if str[i] == "(":
            open[i+1]=open[i]+1
        else:
            open[i+1]  = open[i]

    for i in range(l-2,-1,-1):
        if str[i] ==")":
            close[i]=close[i+1] +1
        else:
            close[i] =close[i+1]

    for j in range(l+1):
        if open[j]==close[j]:
            index = j
    return index

str = "(()))(()()())))"
print(findindex(str))