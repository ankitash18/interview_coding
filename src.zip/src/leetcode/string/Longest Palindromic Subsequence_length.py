"""
The Longest Palindromic Subsequence (LPS) problem is finding the longest subsequences of a string that is also a palindrome.
For example, consider the sequence ABBDCACB.

The length of the longest palindromic subsequence is 5
The longest palindromic subsequence is BCACB
"""

#using recuson with memoization

def findLongestPalindrome(x,i,j):
    #base case
    if i > j:
        return 0
    # If the string `X` has only one character, it is a palindrome
    if i==j:
        return 1

    # If the last character of the string is the same as the first character
    if x[i] ==x[j]:
        # include the first and last characters in palindrome
        # and recur for the remaining substring `X[i+1, j-1]`
        return 2+findLongestPalindrome(x,i+1,j-1)

    '''
          If the last character of the string is different from the first character
            1. Remove the last character and recur for the remaining substring
               `X[i, j-1]`
            2. Remove the first character and recur for the remaining substring
               `X[i+1, j]`
        '''
    return max(findLongestPalindrome(x,i+1,j),findLongestPalindrome(x,i,j-1))

def find(x):
    n = len(x)
    print('The length of the longest palindromic subsequence is',
          findLongestPalindrome(x, 0, n - 1))

X = 'ABBDCACB'
find(X)
#using memoization
#lookup

def findLongestPalindrome1(X, i, j, lookup):
    # base case
    if i > j:
        return 0
    # If the string `X` has only one character, it is a palindrome
    if i == j:
        return 1

        # construct a unique key from dynamic elements of the input
        key = (i, j)

        # If the subproblem is seen for the first time, solve it and
        # store its result in a dictionary
        if key not in lookup:

            ''' If the last character of the string is the same as the first character,
                include the first and last characters in palindrome and recur
                for the remaining substring X[i+1, j-1] '''

            if X[i] == X[j]:
                lookup[key] = findLongestPalindrome(X, i + 1, j - 1, lookup) + 2
            else:
                ''' If the last character of the string is different from the
                    first character

                    1. Remove the last character recur for the remaining substring
                       `X[i, j-1]`
                    2. Remove the first character recur for the remaining substring
                       `X[i+1, j]`
                    3. Return the maximum of the two values '''

                lookup[key] = max(findLongestPalindrome(X, i, j - 1, lookup),
                                  findLongestPalindrome(X, i + 1, j, lookup))

        # Return the subproblem solution from the dictionary
        return lookup[key]


def find1(x):
    # create a dictionary to store solutions to subproblems
    lookup = {}
    print('The length of the longest palindromic subsequence is',
          findLongestPalindrome1(X, 0, len(x) - 1, lookup))


Y= 'ABBDCACB'
find1(Y)