def anagram(s1,s2):
    #replace the space
    s1 = s1.replace(' ','').lower()
    s2 = s2.replace(' ','').lower()

    #edge case  check
    if len(s1) != len(s2):
        return False

    count = {}
    for c in s1:
        if c in count:
            count[c]+= 1
        else:
            count[c] =1

    for c2 in s2:
        if c2 in count:
            count[c2] -=1
        else:
            count[c2] = 1

    for key in count:
        if count[key] != 0:
            return False

    return True


s1 = 'd o g'
s2 = 'g o d'
print(anagram(s1,s2))

#By Counting character

def isanagram1(s1,s2):
    num_chars = 256
    if len(s1) != len(s2):
        return False
    count_str1 = [0]*256
    count_str2 = [0]*256

    for i in s1:
        count_str1[ord(i)] +=1

    for i in s2:
        count_str2[ord(i)] +=1

    for i  in range(num_chars):
        if count_str1[i] != count_str2[i]:
            return False
    return True

print(isanagram1(s1,s2))


