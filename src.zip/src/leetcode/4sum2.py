#using dict,,,,time complexity --o(n2)O unlike o(n**4) in brtue force
def fourSumCount(nums1,nums2,nums3,nums4):
    m ={}
    ans = 0
    num1len = len(nums1)
    num2len = len(nums2)
    num3len = len(nums3)
    numlen4 = len(nums4)

    for  i in range(0,num1len):
        x = nums1[i]
        for j in range(0,num2len):
            y = nums2[j]

            if (x+y not in m):
                m[x+y] = 0

            m[x+y] += 1

    for k in range(0,num3len):
        print(f".k..{k}")
        x = nums3[k]
        for j in range(0,numlen4):
            y = nums4[j]
            print(f"...x is ..{x}..y is {y}")
            target = -(x+y)
            print(f"...targte,,{target}")

            if target in m:
                ans +=m[target]
                print(f"...ans..{ans}")

    print(m)
    print(f"...mpf 1...{m[1]}")
    return ans

{-1: 1, 0: 2, 1: 1}


nums1 = [1,2]
nums2 = [-2,-1]
nums3 = [-1,2]
nums4 = [0,2]

ans = fourSumCount(nums1,nums2,nums3,nums4)
print(ans)