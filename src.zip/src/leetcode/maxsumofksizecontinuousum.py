#Maximum Sum Of K Size Subarray
#using brute force

arr = [2, 6, -9, 7, -1, 5, 4]
k = 3
#6-3+1=4
def brute_force(arr,k):
    ans = 0
    for i in range(0,len(arr)-k+1):
        sum = 0
        for j in range(i,i+k):
            sum += arr[j]

        ans = max(sum,ans)
    return ans


#using sliding window

arr = [2, 6, -9, 7, -1, 5, 4]
k = 3
print(brute_force(arr,k))

def sliding_window(arr,k):

    cursum= 0
    res = 0
    n = len(arr)
    for i in range(0,k):
        cursum += arr[i]

    res = cursum

    for j in range(k,n):
        cursum = cursum +arr[j]-arr[j-k]
        res = max(res,cursum)

    return  res




print(sliding_window(arr,k))
