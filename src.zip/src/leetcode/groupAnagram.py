def groupAnagrams(str):
    ans =[]
    m ={}
    for s in str:
        print(sorted(s))
        sorted_word =''.join(sorted(s))
        if (sorted_word not in m):
            m[sorted_word] = [s]
        else:
            m[sorted_word].append(s)

    for value in m.values():
        ans.append(value)

    return ans



strs = ["eat","tea","tan","ate","nat","bat"]
lis = groupAnagrams(strs)
print(lis)