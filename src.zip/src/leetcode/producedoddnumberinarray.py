#wrtie a function to sort an array so that it produces only odd number

l=[7,9,4,1,1,3,2,5,6,5]

def sort_array(arr):
    #first get only odd numner element in arrar
    newarr = [num for num in arr if num%2 == 1]
    print(newarr)

    length = len(newarr)-1
    print(length)
    for i in range(0,length):
        for j in range(0,length-i):
            print(f"..j...{j}")
            if newarr[j] > newarr[j+1]:
                temp = newarr[j]
                newarr[j] = newarr[j+1]
                newarr[j+1] = temp
    print(newarr)


sort_array(l)