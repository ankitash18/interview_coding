#given an unsported array of number 1 to N number,find the exactly 2 mssing number

l = [4,5,2,1]
#always two of

def find_missing(arr):
    #length will always be n+2
    l = len(arr)+2
    missing_number = []

    for i in range(1,l+1):
        if i not in arr:
            missing_number.append(i)
    print(missing_number)


find_missing(l)


