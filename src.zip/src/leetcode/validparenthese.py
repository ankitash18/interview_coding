#{()}
def ismatch(c1,c2):
    if (c1 == '(' and c2 == ')'):
        return True
    if (c1 == '{' and c2 == '}'):
        return True
    if (c1 == '[' and c2 == ']'):
        return True
    return False


def isValid(s):

        if len(s) % 2 != 0 :
            return False

        st =[] #list as a stack

        for character in s:
                if character in "({[":
                    st.append(character)

                elif len(st) !=0 and character ==')' and st[-1] =='(':
                    st.pop()

                elif len(st) !=0 and character =='}' and st[-1] =='{':
                    st.pop()

                elif len(st) !=0 and character ==']' and st[-1] =='[':
                    st.pop()

                else:
                    st.append(character)
        return len(st) ==0

s ="{([)]}"
print(isValid(s))
