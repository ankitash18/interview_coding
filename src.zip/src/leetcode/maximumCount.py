#give na list,return the number which have maximu mcount


l=[7,9,4,1,1,3,2,5,6,5]

def max_count(arr):

    d = {}
    for i in arr:
        if i in d:
            d[i] += 1
        else:
            d[i] =1
    print(d)

    final_list = []
    max_cnt = 0


    for key,value in d.items():
        if value > max_cnt:
            max_cnt = value


    for key,value in d.items():
        if value == max_cnt:
            final_list.append(key)

    print(final_list)

    #or use the sorted
    d1 = ((value,key) for key,value in d.items())
    d2=sorted(d1,reverse=True)





max_count(l)
