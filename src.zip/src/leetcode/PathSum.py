# Definition for a binary tree node.
class TreeNode:
     def __init__(self, val=0, left=None, right=None):
         self.val = val
         self.left = left
         self.right = right
class Solution:

    def hassun(self,root,sum,cur):
        if (root is None):
            return False
        cur += root.val
        if(cur == sum and root.left is None and root.right is None):
            return True

        return (self.hassun(root.left,sum,cur) or self.hassun(root.right,sum,cur))

    def hasPathSum(self, root, targetSum) :
        return self.hassun(root,targetSum,0)
