class Node:
    def __init__(self,value):
        self.left = None
        self.right = None
        self.data = value


def insert(root,node):
    if (root is None):
        root = node
        return

    if(root.data < node.data):
        if (root.right is None):
            root.right = node
        else:
            insert(root.right,node)

    if(root.data >= node.data):
        if (root.left is None):
            root.left = node
        else:
            insert(root.left,node)


def search(node,key):
    print(f"current node is ..{node.data}")
    if (node is None):
        return None

    if (node.data == key):
        print(f"node found ..")
        return node

    if (node.data < key):
        return search(node.right,key)
    return search(node.left,key)

def minimumvalue(node):
    while(node.left is not None):
        node = node.left
        return node

def deletenode(node,key):
    if(node is None):
        return node

    if(key < node.data):
        node.left = deletenode(node.left,key)

    elif(key > node.right)
        node.right = deletenode(node.right,key)

    else:
        if( node.left is None):
            temp =node.right
            node = None
            return temp
        elif(node.right is None):
            temp = node.left
            node = None
            return temp
        else:
            temp = minimumvalue(node.right)
            node.data = temp.data
            node.right = deletenode(node.right,temp.data)



tree = Node(5)
insert(tree,Node(3))
insert(tree,Node(2))
insert(tree,Node(4))
insert(tree,Node(7))
insert(tree,Node(6))
insert(tree,Node(8))

search(tree,8)