#given an srray of integers,find an non empty subarray whose element sum to zero
import sys
arr =  [-1,-3,4]

def find_subarray(arr,sum):
    length = len(arr)
    min_sum = sys.maxsize
    li = []
    for i in range(0,length):
        cur_sum=0
        #print(cur_sum)
        for j in range(i,length):
            cur_sum = cur_sum + arr[j]
            #print(cur_sum)
            #print(arr[j])
            print(f"..i id,,,{i}")
            print(f"..j id,,,{j}")
            if cur_sum == sum:
                print("found the sum")
                li.append(arr[i:j+1])


    print(li)


find_subarray(arr,0)

#using sliding window

def sli_win(arr,sum):
    curr_sum = 0
    start = 0
    n= len(arr)
    li = []
    for i in range(0,n):
        curr_sum = curr_sum+arr[i]
        print(f"..i..{i}")

        if curr_sum == sum:
            print("found")
            li.append(arr[start:i + 1])

        if curr_sum > sum:
            curr_sum = curr_sum-arr[start]
            start +=1

        print(curr_sum)
    print(li)

arr =  [-1,-3,4]
sli_win(arr,4)
