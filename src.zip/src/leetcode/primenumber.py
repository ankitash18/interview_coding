def countPrimes(n):
    if (n < 2 ):
        return 0
    count =0
    for i in (2,m):
        if (n ==2):
            return 1

    if