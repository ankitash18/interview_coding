#return nth elemtnt form last in linked list
def nthtolast(head,n):
    pointer1 = head
    pointer2 = head

    for _ in range(n):
        if pointer2 is None:
            return None
        else:
            pointer2 = pointer2.next

    while pointer2:
        pointer1 = pointer1.next
        pointer2 = pointer2.next

    return pointer1

