#given an interger array,find all the magic triplets in it.
#magic triple is a group of 3 number whose sum is zero


#using normal brute force
#usinf dict
arr =  [0, -1, 2, -3, 1]

def find_triplet(arr):
    length  = len(arr)
    found = False
    s = set()

    for i in range(0,length-2):
        for j in range(i+1,length-1):
            for k in range(j+1,length):
                if(arr[i]+arr[j]+arr[k] ==0):
                    found = True
                    s.add((arr[i],arr[j],arr[k]))
    if not found:
        return -1
    else:
        return s

print(find_triplet(arr))