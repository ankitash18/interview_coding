import sys

def string_comp(str):
    l = len(str)
    print(sys.version)
    #edge case check
    if l ==0:
        return ""

    if l ==1:
        return str+"1"


    d = {}
    for ch in str:
        if ch in d:
            d[ch] += 1
        else:
            d[ch]  = 1

    print(d)
    newstr = ""
    for key,value in d.items():
        newstr = newstr+f"{key}{value}"

    return newstr



str = "AAAAABBBaaCC"
print(string_comp(str))

def str_comp(s):
    l = len(s)
    print(sys.version)
    # edge case check
    if l == 0:
        return ""

    if l == 1:
        return s + "1"

    cnt = 1
    i =1
    newstr = ""

    while i < l:
        print(f"...s[i] is..{s[i]}")
        if s[i] ==s[i-1]:
            cnt += 1
        else:
            newstr = f"{newstr}{s[i-1]}{cnt}"
            cnt = 1
            print(newstr)
        i +=1
    
    newstr = f"{newstr}{s[i-1]}{cnt}"
    print(newstr)

s = "AAAAABBBaaCC"
print(str_comp(s))