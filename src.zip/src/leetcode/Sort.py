#bubble sort
#first greatest elment wil be at its last place..then next greatest n so on,,,
#so basically in every pass....n-1 comparison need to be done,...

arr = [2,1,7,6,5,3]

def bubble_sort(arr):
    length = len(arr)-1
    for i in range(length):
        for j in range(length-i):
            if arr[j]>arr[j+1]:
                temp = arr[j]
                arr[j] = arr[j+1]
                arr[j+1] = temp

    print(arr)

bubble_sort(arr)


#SELECTION SORT
#EXTRCT ON EMIN ELMEENT IN EACH ITERATION of unsorted array AND PUT IT IN SORTED SIDE OF ARRAY...EACH PASS ONLY ONLY SWPPING


def selecion_sort(arr):
    for i in range(len(arr)):
        min_index = i
        for j in range(i+1,len(arr)):
            if arr[min_index] > arr[j]:
                min_index = j
        temp =arr[i]
        arr[i] = arr[min_index]
        arr[min_index] = temp

    print(arr)

selecion_sort(arr)

#insertion sort-
#select first element from unsorted array and put it in right placr in sorted array in eac hpass
#arr = [2,1,7,6,5,3]
def insertion_sort(arr):
     for i in range(1,len(arr)):
         current_value = arr[i]
         position = i
         while position > 0 and arr[position-1] > current_value:
            arr[position]  =arr[position-1]
            position = position -1

         arr[position]=current_value
     print(arr)

insertion_sort([2,3,1])




