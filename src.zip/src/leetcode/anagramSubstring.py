#Anagram substring search
#brute force

def anagram(s1,s2):
    #replace the space
    s1 = s1.replace(' ','').lower()
    s2 = s2.replace(' ','').lower()

    #edge case  check
    if len(s1) != len(s2):
        return False

    count = {}
    for c in s1:
        if c in count:
            count[c]+= 1
        else:
            count[c] =1

    for c2 in s2:
        if c2 in count:
            count[c2] -=1
        else:
            count[c2] = 1

    for key in count:
        if count[key] != 0:
            return False

    return True

s = "abxaba"
p = "ab"

def anagram_indices(str,pat):
    strlen = len(str)
    patlen = len(pat)
    result = []
    for i in range(0,strlen-patlen+1):
        temp = str[i:i+patlen]
        print(f"..temp is,,,,{temp}")
        if anagram(pat,temp):
            result.append(i)
    return result

print(anagram_indices(s,p))

#usingslicing window

def iscountequal(text_count,pattern_count):
    for i in range(0,256):
        if text_count[i] != pattern_count[i]:
            return False

    return True

def find_indices(text,pattern):
    n = len(text)
    m = len(pattern)
    indices =[]
    text_count = [0]*256
    pattern_count = [0]*256
    for i in range(0,m):
         textval = text[i]
         patval = pattern[i]
         print(ord(textval))


         text_count[ord(textval)] +=1
         pattern_count[ord(patval)] +=1

    print(text_count)
    print(pattern_count)

    for i in range(m,n):
        if iscountequal(text_count,pattern_count):
            indices.append(i-m)

    print(indices)





find_indices(s,p)

