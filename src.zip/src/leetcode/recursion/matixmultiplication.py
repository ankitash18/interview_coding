#rule is that number o f rows in a should be equal to number of column in matrxi b
#a= p*n
#b= n*q

X = [[1, 2],
     [3,4]]
Y = [[1,2],
     [3,4]
     ]
#result is - 3*4(p*q)
#remembr three diffeen size..to need to take 3 input,,for p,q,n
def matximul(x,y):
    numrowsX = len(x) #2
    #print(numrowsX)
    numcolX= len(x[0]) #2
    #print(numrowsX)
    numrowsY = len(y) #2
    #print(numrowsX)
    numcolsY=len(y[0]) #2
    #print(numrowsX)

    C = [[0 for j in range(numcolsY)] for i in range(numrowsX)]

    for i in range(len(C)):
        for j in range(len(C[0])):
            for k in range(len(y)):
                print(f"..i..{i}")
                print(f"...j..{j}")
                print(f"...k..{k}")

                C[i][j] += x[i][k] * y[k][j]

    for row in C:
        print(row)


matximul(X,Y)