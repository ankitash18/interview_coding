#given teo matric,,,fidn the sum of each elment and creste new matrix
# a1 = [[1, 2], [4, 5]]
 #a2 = [[7, 8], [9, 10]]
 #a1			a2   a3
 #[1, 2] [7, 8]   [7   16
 #[4, 5]	[9, 10]  36    50



def sumoftwomatric(m1,m2):
    #row length
    rowlen = len(m1)
    collen = len(m1[0])

    print(rowlen)
    print(collen)
    #create an emptry matrix of the same size
    m3 = multi_list = [[0 for col in range(collen)] for row in range(rowlen)]
    print(m3)
    for row in range(rowlen):
        for col in range(collen):
            m3[row][col] = m1[row][col] +m2[row][col]

    print(m3)



a1 = [[1, 2], [4, 5]]
a2=[[7, 8], [9, 10]]

sumoftwomatric(a1,a2)