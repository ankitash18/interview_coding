#day1 - 11,15,10,6
#day2  -10,14,11,5
#day3 -12,17,12,8
#day4 -15,18,14,9
#o(m,n) - m -rows,n column
#timecolplexity - accessign an element - o(1)
#traversing - o(mn)
twoarray =[[11,15,10],[10,14,11],[12,17,12],[12,17,12]]

print(twoarray[0][1]*twoarray[1][0])
#       0  1  2  3
#    0[11,15,10,6],\
  #  1[10,14,11,5],\
  #  2[12,17,12,8],\
 #   3[12,17,12,8]

def accessarrayelement(arr,rowindex,colindex):
    print(len(arr)) #retunrn number of rows
    print(len(arr[0])) #retun number of column
    if rowindex >= len(arr) and colindex >= len(arr[0]):
        print('incorrect index')
    else:
        print(arr[rowindex][colindex])


accessarrayelement(twoarray,1,1)
#traversing an 2d array

#contur to first row ,then 2dn row,then 3rd row and in each row,,visit all columns

def travese2darr(arr):
    #length of row - len(arr)
    #length of col - len(col)
    print(twoarray)
    for i in range(len(arr)):#rows....
        for j in range(len(arr[0])):#..column
            print(arr[i][j])

#travese2darr(twoarray)


#searching in two d array
#linear search..loop through each column of each row..startign from zero and compare the valyue agaisnt given value

def searchtwodarr(arr,d):
    rowlen=len(arr)
    collen = len(arr[0])
    for row in range(rowlen):
        for col in range(collen):
            if arr[row][col] == d:
                print(f"found at ..{row} {col}")
                return
    print("Not found")
    return

searchtwodarr(twoarray,14)

#delete elemtn from array
#either delete row or column