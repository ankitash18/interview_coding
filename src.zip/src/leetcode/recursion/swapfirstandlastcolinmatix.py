def  min_max(m1):

    rowlen = len(m1)
    collen = len(m1[0])
    print(m1)

    for row in range(rowlen):
         temp = m1[row][0]
         m1[row][0] = m1[row][collen-1]
         m1[row][collen-1] =temp

    for i in range(rowlen):
        for j in range(collen):
            print(m1[i][j],end =" ")
        print()

m1 = [[1,2,3],[4,5,6],[7,8,9]]
min_max(m1)