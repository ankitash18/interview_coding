def dectobinn(n):
    if (n == 0):
        return 0
    else:
        return n%2 + 10 * dectobinn(int(n/2))

print(dectobinn(13))