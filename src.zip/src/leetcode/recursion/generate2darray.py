#Write a Python program which takes two digits m (row) and n (column) as input and generates a two-dimensional array.
# The element value in the i-th row and j-th column of the array should be i*j.


def genarray(numrow,numcol):

    multi_list = [[0 for col in range(numcol)] for row in range(numrow)]
    print(multi_list)
    for row in range(numrow):
        for col in range(numcol):
            multi_list[row][col] = row*col

    print(multi_list)

genarray(4,3)




