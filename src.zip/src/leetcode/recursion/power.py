def power(n,exponent):
    assert exp >=0 and int(exp) == exp,'the number must be positive integer only'
    if (exponent ==0):
        return 1
    if (exponent ==1):
        return n
    else:
        return n*power(n,exponent-1)

print(power(2,3))