def  min_max(m1):

    max_element = m1[0][0]
    min_element = m1[0][0]

    rowlen = len(m1)
    collen = len(m1[0])
    for row in range(rowlen):
        for col in range(collen):
            if m1[row][col] > max_element:
                max_element = m1[row][col]
            if m1[row][col] < min_element:
                min_element = m1[row][col]

    print(max_element)
    print(min_element)





m1 = [[1, 2],[3,4],[5,6],[7,8]]
min_max(m1)