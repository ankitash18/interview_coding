#given a 2d array/list..find the sum of diagonal elemtn

myList2D= [[1,2,3],[4,5,6],[7,8,9]]
print(myList2D)
 #   0 1  2
# 0[1,2,3],
# 1[4,5,6],
# 2 [7,8,9]

#loop through two d array...diagonal element are elements where row =column

def sumofdiagonal(arr):
    lenrow = len(arr) #length of row
    lencol = len(arr[0]) #length of col
    sum = 0
    for row in range(lenrow):
        for col in range(lencol):
            if row ==col:
                sum += arr[row][col]
    return sum


result = sumofdiagonal(myList2D)
print(result)

[[1, 2, 3],
 [4, 5, 6],
 [7, 8, 9]]