def sorted_num_arr(arr):


    d = {}
    for num in arr:
        if num in d:
            d[num] +=1
        else:
            d[num] = 1

    pointer = 0

    for i in   range(1,10):
        while i in d and d[i] > 0:
            arr[pointer] = i
            pointer+= 1
            d[i] -= 1

    return arr



arr = [5,5,1,3,7,7,7,8,8,9,2]

print(sorted_num_arr(arr))
