def sumofdigit(n):

    if (n ==0):
        return 0
    else:
        return int(n%10)+ sumofdigit(n/10)
n = 15
print(sumofdigit(int(n)))