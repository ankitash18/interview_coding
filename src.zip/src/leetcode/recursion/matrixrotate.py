#roate matric by 90 percentage

m1 = [[1, 2,3], [4, 5,6],[7,8,9]]


def rotatematrix(m1):
    rowlen = len(m1)
    collen = len(m1[0])
    print(m1)

    # create an emptry matrix of the same size
    m3 = [[0 for col in range(collen)] for row in range(rowlen)]
    m4 = [[0 for col in range(collen)] for row in range(rowlen)]
    #firat will tranpose...means..convert row to colmn and col to row
    #then reverse row valyues clock wise
    for i in range(rowlen):
        for j in range(collen):
            m3[i][j] = m1[j][i]
    #print(m3)
    for i in range(len(m1)):
        for j in range(len(m1[0])):
            print(m3[i][j],end= " ")
        print()

    for i in range(len(m3)):
        for j in range(len(m3[0])-1,-1,-1):


    for i in range(len(m3)):
        for j in range(len(m3[0])):
            print(m3[i][j], end=" ")
        print()


rotatematrix(m1)