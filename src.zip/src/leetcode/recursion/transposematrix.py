def tranpose_mat(m1):
    rowlen = len(m1)
    collen = len(m1[0])
    print(m1)

    # create an emptry matrix of the same size
    m3 = multi_list = [[0 for col in range(collen)] for row in range(rowlen)]

    for row in range(rowlen):
        for col in range(collen):
            m3[row][col] =m1[col][row]

    print(m3)


m1 = [[1, 2,3], [4, 5,6],[7,8,9]]
tranpose_mat(m1)