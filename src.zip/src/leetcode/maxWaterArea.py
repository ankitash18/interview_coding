#brute force
def maxArea( height) :
    max_area = 0
    n = len(height)-1
    for p1 in range(0, n):
        for p2 in range(p1 + 1, n+1):
            print(f"...current  [p1]..{p1}")
            print(f"...current  p2..{p2}")

            length = min(height[p1], height[p2])
            print(f"...current length..{length}")

            width = p2 - p1
            print(f"...current  width.{width}")
            area = length * width
            max_area = max(max_area,area)
            print(f"...current max area..{max_area}")
           # print(f"...current  area..{area}")
    return max_area

height = [1,8,6,2,5,4,8,3,7]
maxarea = maxArea(height)
print(f"mazarwa is..{maxarea}")

#using one loop
def maxArea1( height) :
    max_area = 0
    r = len(height)-1
    l = 0
    while(l<r):
        length = min(height[l], height[r])
        width = r-l
        area = length * width
        max_area = max(max_area, area)
        if(height[l] < height[r]):
            l += 1
        else:
            r -=1
    return max_area

height = [1,8,6,2,5,4,8,3,7]
maxarea = maxArea1(height)
print(f"mazarwa is..{maxarea}")