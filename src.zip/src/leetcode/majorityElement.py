def majorityElement(nums):
    m = {}
    for num in nums:
        if num not in m:
            m[num] = 1

        if m[num] > len(nums)//2:
            return num

        else:
            m[num] += 1

nums = [3,2,3,4,4,4]
ans = majorityElement(nums)
print(ans)