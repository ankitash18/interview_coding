def removeNthFromEnd(head,n):
        first = head
        second = head

        for i  in range(n):
            first = first.next

        while (first is not None):
            first = first.next
            second = second.next

        second.next = second.next.next

        return head