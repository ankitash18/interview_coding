"""
push(): Insert a new element into the stack i.e just inserting a new element at the beginning of the linked list.
pop(): Return the top element of the Stack i.e simply deleting the first element from the linked list.
peek(): Return the top element.
display(): Print all elements in Stack.
"""
#create a node class

class Node:
    def __init__(self,data):
        self.data = data
        self.next = None

class stack:

    #head is daulf null
    def __init__(self):
        self.head = None

    # Checks if stack is empty
    def isEmpty(self):
        if self.head is None:
            print("stakc is empty")
            return True
        else:
            return False
        # Method to add data to the stack
        # adds to the start of the stack

    def push(self,data):
            if self.head is None:
                self.head = Node(data)
            else:
                newnode = Node(data)
                newnode.next = self.head
                self.head = newnode
        # Remove element that is the current head (start of the stack)
    def pop(self):

            if self.isEmpty():
                return None
            else:
                # Removes the head node and makes# the follwng one the new head
                removehead = self.head
                self.head = self.head.next
                removehead.next = None
                return removehead.data
        # Returns the head node data
    def peek(self):
            if self.isEmpty():
                return None
            else:
                return self.head.data

        # Prints out the stack
    def display(self):
            iternode = self.head
            if self.isEmpty():
                print("stack is empty")
            else:

                while(iternode != None):
                    print(iternode.data,"-->",end=" ")
                    iternode = iternode.next

            return



mystack =stack()
mystack.isEmpty()

mystack.push(1)
mystack.push(2)
mystack.push(3)
mystack.display()
mystack.pop()
mystack.display()


