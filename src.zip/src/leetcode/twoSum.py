#array pair
#wrtie a code to fidn the sum pof amy teo numbers in s given array that wil leb equal tio x

def twoSum(nums,target):
    m ={}
    n = len(nums)
    for p1 in range(0,n):
        goal = target - nums[p1]
        if(goal in m):
            return [m[goal],p1]
        m[nums[p1]] =p1


nums = [2,7,11,15,8,1]
target = 9
p1,p2 = twoSum(nums,target)
print(f"p1 and p2...{p1}-{p2}")


#using set

def twoSum1(arr,k):
    seen = []
    output = set()

    for i in arr:
        target = k-i
        if target not in seen:
            seen.append(i)
        else:
            output.add((target,i))


    return output

arr = [1,2,3,4,4,5,6,7,8,9]
k= 8

output = twoSum1(arr,k)
print(f"..output is..{output}")

