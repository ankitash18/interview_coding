def oddEvenList(head):
         if (not head):
             return None

         odd = head
         even = odd.next
         evenlist = even

         while(even and even.next):
             odd.next = even.next
             odd = odd.next

             even.next = odd.next
             even = even.next

         odd.next=evenlist

         return head