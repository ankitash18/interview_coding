def containsDuplicate(nums):
    numset = set(nums)

    if len(numset) == nums:
        return False
    else:
        return True

nums = [1,2,3,4]
#ans  =containsDuplicate(nums)
#print(ans)

#using dict
from collections import defaultdict

def containsDuplicate1(nums):
    m={}
    for num in nums:
        if num in m:
            return True
        else:
            m[num]  = 1
    return False


nums1 = [1,2,1,4]
ans  =containsDuplicate1(nums1)
print(ans)