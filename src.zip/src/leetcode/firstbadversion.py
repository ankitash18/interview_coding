# The isBadVersion API is already defined for you.
# def isBadVersion(version: int) -> bool:
def firstBadVersion(n):
    for i in range(1,n):
        if(isBadVersion(i) == true):
            return i

#optimal solution
def firstBadVersion1(n):
    left = 1
    right = n
    while(left < right):
        mid = left +right //2
        if(isBadVersion(mid))
            right = mid
        else
            left = mid+1
    return left