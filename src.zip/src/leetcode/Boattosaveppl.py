def numrescueBoats(people,limit):
     #sorting the array
    people.sort()
    heavyp = len(people) -1
    lightp = 0
    boats = 0
    while(lightp <= heavyp):
        if(lightp == heavyp):
            boats += 1
            break

        if(people[heavyp] + people[lightp] <= limit):
            boats += 1
            heavyp -= 1
            lightp += 1
        else:
            boats += 1
            heavyp -= 1

    return boats


people = [3,2,3,1]
numboats = numrescueBoats(people,4)

print(f"number of boats....{numboats}")

