#using dict

def singleNumber(num):
    numberdict = {}
    for i in num:
        if i  in numberdict:
            numberdict[i] += 1
        else:
            numberdict[i] = 1

    for key,value in numberdict.items():
        if numberdict[key] == 1:
            return key

nums = [1,3,1,9,3]
n = singleNumber(nums)
print(n)
