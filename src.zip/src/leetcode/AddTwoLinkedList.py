"""
Given two numbers represented by two lists,
write a function that returns the sum list.
The sum list is a list representation of the addition of two input numbers.
Input:
List1: 5->6->3 // represents number 563
List2: 8->4->2 // represents number 842
Output:
Resultant list: 1->4->0->5 // represents number 1405
Explanation: 563 + 842 = 1405
The steps are:

Traverse the two linked lists from start to end
Add the two digits each from respective linked lists.
If one of the lists has reached the end then take 0 as its digit.
Continue it until both the end of the lists.
If the sum of two digits is greater than 9 then set carry as 1 and the current digit as sum % 10
"""

#first will create a node class

class Node:
    def __init__(self,data):
        self.data =data
        self.next = None


class Linedlist:

    # Function to initialize head
    def __init__(self):
        self.head = None

    #function to insert new element at the beginning to the list
    def push(self,data):
        target = Node(data)
        target.next = self.head
        self.head = target

    # Add contents of two linked lists and
    # return the head node of resultant list
    def addtwolist(self,first,second):
        prev = None
        temp = None
        carry = 0
        #while both the list exist
        while(first is not None and second is not None):
                # Calculate the value of next digit
                # in resultant list
                # The next digit is sum of following
                # things
                # (i) Carry
                # (ii) Next digit of first list (if
                # there is a next digit)
                # (iii) Next digit of second list (if
                # there is a next digit)
                if (first != None):
                     fdata = first.data

                sdata = 0 if second is None else second.data
                sum  =carry+fdata+sdata

                #update carry for next calcualtion
                carry =1 if sum >= 10 else 0

                #update sum if it is greater then zero
                sum = sum if sum < 10 else sum%10

                #create a new node with sum as data
                temp = Node(sum)

                #if this is the first node,then set it as head
                if self.head is None:
                    self.head = temp
                else:
                    prev.next = temp
                #move first n seconf pointer to next location
                if first is not None:
                    first= first.next
                if second is not None:
                    second  = second.next

                if carry > 0:
                    temp.next = Node(carry)
        return self.head



    def printlist(self):
        temp = self.head
        linked_list = ""
        while (temp):
            linked_list += str(temp.data) + "==>"
            temp = temp.next
            print(linked_list)







l1 = Linedlist()
l1.push(5)
l1.push(6)
l1.push(7)

l1.printlist()

l2 = Linedlist()
l2.push(8)
l2.push(4)
l2.push(2)
l2.printlist()

res = Linedlist()
res.addtwolist(l1, l2)
res.printlist()
