#guage frmuala
#n*n+1/2
def missingNumber(nums):
    pass

#using dict
def missingnumer1(nums):
    presentnumberlist = {}
    for input in nums:
        presentnumberlist[input] = "yes"


    for i in range(0,len(nums)+3):
        if (i  not in presentnumberlist):
            break
    return i

nums = [4,3,5,2]
mssing= missingnumer1(nums)
print(mssing)
