#preserve orde,,,fnd unique


l =[1,1,3,2,5,6,5]
#output shoould be [1,3,2,5,6]

#basically remove duplicates


def rem_deu(arr):

    final_list = []
    for i in arr:
        if i not in final_list:
            final_list.append(i)
        else:
            continue
    print(final_list)

rem_deu(l)
