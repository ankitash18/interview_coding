def maxProfit(prices):
    buyprice = float("inf")
    profit = 0
    for i,price in enumerate(prices):
        if (buyprice > price):
            buyprice = price
        else:
            profit = max(profit,price-buyprice)
    return profit
