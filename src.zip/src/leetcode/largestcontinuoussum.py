#kadane algo

def contsum(arr):
    s = 0
    e=0
    str=0
    if len(arr) == 0:
        return 0

    max_so_far =current_sum = arr[0] #sum til lcurrent position

    for i in arr[1:]:

        current_sum =max(current_sum+i,i) #

        max_so_far = max(max_so_far,current_sum) #1


    return max_so_far



arr =  [-2,1,-3,4,-1,2,1,-5,4]
print(contsum(arr))

#brute_force

def brute_force(arr):
    max_sum = 0
    s=  0
    e = 0
    maxsubarray = []
    for i in range(0,len(arr)):
        curr_sum = 0
        for j in range(i,len(arr)):
            curr_sum = curr_sum +arr[j]
            if curr_sum > max_sum:
                max_sum = curr_sum
                e = j
                s=i


    print(f",,{e}..{s}")

    print(f"..masubarray....{arr[s:e+1]}")

    return max_sum


print(brute_force(arr))

