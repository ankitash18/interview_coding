#left right root
#@     10
#     /   \
#    20    12
#    /  \
#    3   8


#post order - 3 ,8,20,12,10

class Node:
    def __init__(self,value):
        self.left = None
        self.right = None
        self.data = value


def postorder(node):
    if (node is not None):

        postorder(node.left)
        postorder(node.right)
        print(node.data)



root = Node(4)
root.left = Node(5)
root.right = Node(6)

root.left.left = Node(7)
