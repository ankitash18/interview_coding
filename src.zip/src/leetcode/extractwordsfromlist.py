st ="01UK02US03IN"
temp =""
temp2 =""
l1 = []
l2 =[]
for i in range(0,len(st)):
    if st[i].isdigit():
        temp += st[i]
        if temp2 !="":
            l2.append(temp2)
            temp2 = ""
    elif st[i].isalpha():
        temp2 += st[i]
        print(temp2)
        if temp != "":
            l1.append(temp)
            temp = ""
    print(i)
    print(len(st))
    if temp2 !="" and i==len(st)-1:
        l2.append(temp2)
        temp = ""



print(l1)
print(l2)