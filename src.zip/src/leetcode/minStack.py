class MinStack:

    def __init__(self):
        self.st = []

    def push(self, x: int) -> None:
        curmin = self.getmin()
        if curmin is None or curmin >x:
            curmin = x
        self.st.append((x,curmin))

    def pop(self) -> None:
         self.st.pop()

    def top(self) -> int:
       return  self.st[-1][0] if self.st else None

    def getMin(self) -> int:
        if not self.st:
            return None
        else:
            self.st[-1][1]
