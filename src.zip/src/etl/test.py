import sys

from pyspark.sql import SparkSession
import luigi
from pyspark.sql import functions as F
from dataclasses import dataclass
from pyspark.sql.types import StructType,StructField, StringType, IntegerType,DateType
import time.datetime

str = '2020-04-16'
str1 = '2020-05-06'

current_dste = datetime.strptime(str,'%Y-%m-%d')
prev_dste = datetime.strptime(str1,'%Y-%m-%d')

print(current_dste)
print(prev_dste)

days_bet =relativedelta(prev_dste,current_dste)
print(days_bet.months +(12 * days_bet.years))

m1 = prev_dste.year *12 + prev_dste.month
m2 = current_dste.year *12 + current_dste.month

diff = (prev_dste.year - current_dste.year) *12 + (prev_dste.month - current_dste.month)

print(f"diff...{diff}")







if __name__ == "__main__":

    def loop_through_df(x):
        final_list =[]
        filter_ind = 0
        length = len(x.new_col_list)
        for i in x.new_col_list:
             if i[2] != 10146:
                 filter_ind = 0
                 final_list.append(i)
             else:
                 final_list


        return (x.acct_num_key,final_list)



    spark = SparkSession.builder.master("local[*]").appName("shufle join demo").getOrCreate()

    goalsDf = [
        ("CUS000150815_1", "2020-04-01",10397),
        ("CUS000150815_1", "2020-05-01",10397),
        ("CUS000150815_1", "2020-07-01",10416),
        ("DLS000120414_1" ,"2020-09-01",10416),
        ("DLS000120414_1", "2020-04-01",10397),
        ("DLS000120414_1", "2020-06-01",10415),
        ("CUS000150816_1", "2020-09-01",10397)
    ]
    schema = StructType([ \
        StructField("acct_num_key", StringType(), True), \
        StructField("treatment_date", StringType(), True), \
        StructField("program_id", IntegerType(), True),
        ])

    df = spark.createDataFrame(data=goalsDf,schema=schema)

    df1 = df.withColumn("treatment_date",df["treatment_date"].cast(DateType())).orderBy(["acct_num_key","treatment_date"])

    df2 = df1.withColumn("combined",F.struct(F.col("treatment_date"))) \
            .groupBy("acct_num_key") \
            .agg(F.collect_list("combined").alias("new_treatment_date"))

    #filtered_df = df2.rdd.map(lambda x:loop_through_df(x)).toDF(["acct_num_key","new_col_list1"])

    df2.show(10,False)
    #print(filtered_df)
    #filtered_df.show(10,False)
    #filtered_df.printSchema()

    print(sys.version)
