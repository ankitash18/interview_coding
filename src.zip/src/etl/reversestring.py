def reverse_slicing(s):
    return s[::-1]

input_str = 'ABç∂EF'
print(reverse_slicing(input_str))

def rev_loop(str):
    length = len(str) -1
    s1 = ''

    while length >=0:
        s1 = s1+str[length]
        print(s1)
        length -= 1
    return s1

print(rev_loop(input_str))