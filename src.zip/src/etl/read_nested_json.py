from pyspark.sql import SparkSession

from pyspark.sql import functions as F

spark = SparkSession\
                    .builder\
                    .master("local[1]")\
                    .appName("pysparkpoc")\
                    .enableHiveSupport()\
                    .getOrCreate()

orderdf = spark.read.format("json")\
                    .option("inferSchema",True) \
                    .option("multiline",True) \
                    .load("C:\\Users\\10679197\\PycharmProjects\\pythonProject\\src\\etl\\sample.json")
#orderdf.show(truncate=False)
orderdf1 = orderdf.withColumn("ordersnew",F.explode("datasets"))

parseorderdf = orderdf1.withColumn("customerId",F.col("ordersnew").customerId)\
                       .withColumn("orderId",F.col("ordersnew").orderId) \
                        .withColumn("orderDate",F.col("ordersnew").orderDate) \
                        .withColumn("shipmentDetails",F.col("ordersnew").shipmentDetails) \
                        .withColumn("orderDetails",F.col("ordersnew").orderDetails) \
                         .drop("ordersnew","datasets")


parseorderdf1 = parseorderdf.withColumn("productdetails",F.explode("orderDetails"))

parseorderdf2 = parseorderdf1.withColumn("productId",F.col("productdetails").productId) \
                            .withColumn("quantity",F.col("productdetails").quantity) \
                            .withColumn("sequence", F.col("productdetails").sequence) \
                            .withColumn("totalPrice", F.col("productdetails").totalPrice) \
                            .withColumn("city", F.col("shipmentDetails").city) \
                            .withColumn("country", F.col("shipmentDetails").country) \
                            .withColumn("state", F.col("shipmentDetails").state) \
                            .drop("productdetails","shipmentDetails","orderDetails")

parseorderdf2.printSchema()
parseorderdf2.show(truncate=False)
