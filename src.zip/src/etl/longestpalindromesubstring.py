

#using brute force
str = 'banana'

def longest(str):
    max_len = 0
    res = ''
    if len(str) < 2:
        return len(str)
#str = 'geeks'
    for i in range(len(str)):
        for j in range(i+1,len(str)):
            curr = str[i:j+1]
            print(f",,,,curr.....{curr}")
            print(f",,,,currrev.....{curr[::-1]}")
            if curr == curr[::-1]:
                if len(curr) > max_len:
                    max_len = len(curr)
                    res = curr
                    print(f"max len..{max_len}")
    return res

print(longest(str))