
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import StringType
from pyspark.sql.functions import pandas_udf,PandasUDFType
from pyspark import SparkFiles

def longest(str):
    max_len = 0
    res = ''
    if len(str) < 2:
        return len(str)
#str = 'geeks'
    for i in range(len(str)):
        for j in range(i+1,len(str)):
            curr = str[i:j+1]
            print(f",,,,curr.....{curr}")
            print(f",,,,currrev.....{curr[::-1]}")
            if curr == curr[::-1]:
                if len(curr) > max_len:
                    max_len = len(curr)
                    res = curr
                    print(f"max len..{max_len}")
    return res




spark = SparkSession\
                    .builder\
                    .master("local[1]")\
                    .appName("pysparkpoc")\
                    .enableHiveSupport()\
                    .getOrCreate()

datafdf = spark.read.text("C:\\Users\\10679197\\PycharmProjects\\pythonProject\\src\\etl\\palindrome_file.txt")\

longestudf = F.udf(lambda z: longest(z),StringType())

newdf = datafdf.withColumn("palindrome_long",longest(F.col("value")))

newdf.show()


