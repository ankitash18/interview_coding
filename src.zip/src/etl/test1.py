from datetime import datetime
from dateutil.relativedelta import relativedelta
import django
import xml.etree.ElementTree as xet
import boto3

cleint =- boto3.client('athena')

b = ['2020-04-16','2020-05-06','2020-06-28','2020-07-09','2020-09-10','2020-12-15','2021-04-02','2021-11-02']

def getdate(l1,rec_num,current_date):

    pre_covid_dt = None
    pre_covid_temp=None
    if rec_num == 0:
        pre_covid_dt = l1[0]
        pre_covid_temp = l1[0]
        return pre_covid_dt,pre_covid_temp
    else:
         for i in range(rec_num-1,-1,-1):
            pre_date = datetime.strptime( l1[i],'%Y-%m-%d')
            curr_date = datetime.strptime(current_date,'%Y-%m-%d')
            days_bet = relativedelta(curr_date, pre_date)
            months_bet = days_bet.months +(12 * days_bet.years)
            if months_bet >= 6:
                pre_covid_dt = pre_date
                pre_covid_temp =curr_date
                break
            else:
                pre_covid_dt = pre_date
                pre_covid_temp = pre_date
                break


    return pre_covid_dt,pre_covid_temp



dt = getdate(b,1,'2020-05-06')
print(f"pre_covid_dt is ...{dt[0]} and...pre_covid_temp..{dt[1]}")

