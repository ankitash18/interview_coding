str ='geeks'

print(str[0:len(str)])