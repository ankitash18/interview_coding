import sys

from pyspark.sql import SparkSession

spark = SparkSession \
    .builder \
    .master("local[1]") \
    .appName("pysparkpoc") \
    .enableHiveSupport() \
    .getOrCreate()

# empDF = spark.createDataFrame(data=emp, schema = empcols)

fielname = "C:\\Users\\10679197\\Desktop\\JsonSourceCode\\file"

testDf = spark.read.format("json") \
                  .option("inferSchema", "true") \
                  .option("multiLine", "true") \
                 .load("sample.json")



testDf.show()
