import requests
import json
from pyspark.sql import SparkSession
from pyspark.sql.functions import col,udf,explode
from pyspark.sql.types import StringType,StructType,StructField,IntegerType,ArrayType
from pyspark.sql.functions import window

#url will be given to us


respnse = requests.request('GET','https://randomuser.me/api/')

data = respnse.text

parsed_json = json.loads(data)

print(parsed_json)

with open('json_api.json','w') as f:
    json.dump(parsed_json,f)

spark = SparkSession\
                    .builder\
                    .master("local[1]")\
                    .appName("pysparkpoc")\
                    .enableHiveSupport()\
                    .getOrCreate()

testDf = spark.read.format("json") \
                  .option("inferSchema", "true") \
                  .option("multiLine", "true") \
                 .load("json_api.json")

testDf.show(10)

def executeRestApi(verb, url, headers, body):
  #
  headers = {
      'content-type': "application/json"
  }
  res = None
  # Make API request, get response object back, create dataframe from above schema.
  try:
    if verb == "get":
        res = requests.get(url, data=body, headers=headers)
    else:
        res = requests.post(url, data=body, headers=headers)
  except Exception as e:
    return e

  if res != None and res.status_code == 200:
    return json.loads(res.text)
  return None

schema = StructType([
  StructField("Count", IntegerType(), True),
  StructField("Message", StringType(), True),
  StructField("SearchCriteria", StringType(), True),
  StructField("Results", ArrayType(
    StructType([
      StructField("Make_ID", IntegerType()),
      StructField("Make_Name", StringType())
    ])
  ))
])

udf_executeRestApi = udf(executeRestApi, schema)

from pyspark.sql import Row
headers = {
    'content-type': "application/json"
}
body = json.dumps({
})
RestApiRequestRow = Row("verb", "url", "headers", "body")
request_df = spark.createDataFrame([
            RestApiRequestRow("get", "https://vpic.nhtsa.dot.gov/api/vehicles/getallmakes?format=json", headers, body)
          ])

result_df = request_df \
             .withColumn("result", udf_executeRestApi(col("verb"), col("url"), col("headers"), col("body")))

df = result_df.select(explode(col("result.Results")).alias("results"))
df.select(collapse_columns(df.schema)).show()