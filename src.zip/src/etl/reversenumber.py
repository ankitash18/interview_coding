n= 121

def reverse(n):
    rev = 0
    while n > 0:
        rem = n%10
        print(rem)
        rev = rev*10+rem
        print(",,,,")
        n = n//10
        print(n)

    return rev


def ispalindrome(n):
    if n < 0:
        return False

    rev = reverse(n)
    print(rev)
    print(n)

    if rev == n:
        return True
    else:
        return False


print(ispalindrome(n))
