import snowflake
import pandas as pd
import getpass



dict = {4:'A',2:'B',3:'C'}

a = dict.keys()

b = list(a)

print(f",,b is..{b}")

print(f"a....{a}..type of a..{type(a)}")

print(f"...key are...{max(dict.keys())}")

print(f"..max form b....{max(b)}")
print

