str = "madam"

def check_palindrome(str):

    for i in range(0,len(str)//2):
        if str[i] != str[len(str)-1-i]:
            return False

        return True

print(check_palindrome(str))