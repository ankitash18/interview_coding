#load the file

from pyspark.sql import SparkSession
from pyspark.sql import functions as F
import pydeequ

def removePunctuation(column):
    return F.trim(F.lower(F.regexp_replace(column,'([^\s\w_]|_)+',''))).alias("sentence")

spark = SparkSession\
                    .builder\
                    .master("local[1]")\
                    .appName("pysparkpoc")\
                    .enableHiveSupport()\
                    .getOrCreate()



datafdf = spark.read.text("C:\\Users\\10679197\\PycharmProjects\\pythonProject\\src\\etl\\shakespere.txt")\
                    .select(removePunctuation(F.col("value")))


"""
Before we can use the
wordcount()
function, we have to address two issues with theformat of the DataFrame:
The first issue is that that we need to split each line by its spaces.
The second issue is we need to filter out empty lines or words.



"""

newdf= datafdf.withColumn("splitcol",F.split(F.col("sentence")," "))
newdf1 = newdf.withColumn("word",F.explode(F.col("splitcol"))).filter("word <> '' ").drop("splitcol","splitcol")

newdf2 = newdf1.groupBy("word").agg(F.count("word").alias("word_count")).orderBy(F.col("word_count").desc())

newdf3 = newdf1.withColumn("collength",F.length("word")).orderBy(F.col("collength").desc())
newdf3.show(10)