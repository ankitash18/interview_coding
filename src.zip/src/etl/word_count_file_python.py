text =  open ('C:\\Users\\10679197\\PycharmProjects\\pythonProject\\src\\etl\\sample.txt','r')

d = {}
for line in text:
    words = line.strip().lower().split(" ")
    print(words)
    for word in words:
        if word in d:
            d[word] +=1
        else:
            d[word] =1

for key,value in d.items():
    print(key,":",value)

