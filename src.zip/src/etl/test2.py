import sys

from pyspark.sql import SparkSession
import luigi
from pyspark.sql import functions as F
from pyspark.sql import Window
import snowflake



emp =[('0460_1',10397,'2020-04-16',1,'2020-04-01'),
('0460_1',10397,'2020-05-07',2,'2020-04-01'),
('0460_1',10397,'2020-07-25',3,'2020-04-01'),
('0460_1',10397,'2020-09-20',4,'2020-04-01'),
('0460_1',10397,'2020-10-02',5,'2020-04-01'),
('0460_1',10397,'2020-10-03',6,'2020-04-01'),
('7494_1',10397,'2020-11-05',1,'2020-06-01'),
('7494_1',10397,'2020-12-10',2,'2020-06-01'),
('7494_1',10397,'2021-01-15',3,'2020-06-01'),
('7495_1',10397,'2020-12-05',1,'2020-06-01'),
('7495_1',10397,'2021-07-10',2,'2020-06-01'),
('7495_1',10397,'2022-01-15',3,'2020-06-01'),
('7496_1',10397,'2020-06-01',1,'2020-12-05'),
('7496_1',10397,'2021-07-10',2,'2020-12-05'),
('7496_1',10397,'2022-01-15',3,'2020-12-05'),
('4948_1',10397,'2020-10-06',1,'2020-04-01'),
('4948_1',10397,'2021-02-25',2,'2020-04-01'),
('4948_1',10397,'2021-04-21',3,'2020-04-01'),
]

empcols = ["acct_num_key","program_id","treatment_date","record_number","hist_covid_date"]

spark = SparkSession\
                    .builder\
                    .master("local[1]")\
                    .appName("pysparkpoc")\
                    .enableHiveSupport()\
                    .getOrCreate()

#empDF = spark.createDataFrame(data=emp, schema = empcols)


testDf = spark.read.csv("C:\Users\10679197\Desktop\JsonSourceCode",header = True, sep =",")

testDf.show()


#runnigSum = Window.partitionBy("acct_num_key","program_id").orderBy("treatment_date")

#runnigSum1 = Window.partitionBy("acct_num_key","program_id").orderBy("treatment_date").rowsBetween(-sys.maxsize,0)


precovidtemp = """
                    CASE
                        WHEN record_number == 1 then null
                        WHEN  record_number > 1 and flag_ind_lag = 0 then treatment_date
                        
                    END
                        """


precovidtempnew = """
                    CASE
                        WHEN record_number == 1  then null
                        else pre_covid_temp_new
                    END
                        """

flag = """
        CASE 
            WHEN record_number == 1 and months_between(to_date(treatment_date,'yyyy-MM-dd'),to_date(hist_covid_date,'yyyy-MM-dd')) >= 6.0 then 0
            WHEN record_number > 1 and pre_covid_temp_lag is null and months_between(to_date(treatment_date,'yyyy-MM-dd'),to_date(hist_covid_date,'yyyy-MM-dd')) >= 6.0 THEN 0
            WHEN record_number > 1 and pre_covid_temp_lag is not null THEN
                                CASE WHEN pre_covid_temp_lag > hist_covid_date and months_between(to_date(treatment_date,'yyyy-MM-dd'),to_date(pre_covid_temp_lag,'yyyy-MM-dd')) >= 6.0 THEN 0
                                     WHEN pre_covid_temp_lag < hist_covid_date and months_between(to_date(treatment_date,'yyyy-MM-dd'),to_date(hist_covid_date,'yyyy-MM-dd')) >= 6.0 THEN 0
                                     ELSE -1
                                 END
            ELSE -1
        END
        """


covid_ind = """
            CASE WHEN month_diff >= 6.0 THEN   treatment_date            
            ELSE null
            END
            
            """

flg_condiiton = """
            CASE WHEN months_between(to_date(hist_dt1_lag,'yyyy-MM-dd'),to_date(treatment_date,'yyyy-MM-dd')) >= 6.0 THEN   1            
            ELSE 0
            END
            
            """

flg2_condiiton = """
            CASE WHEN months_between(to_date(treatment_date,'yyyy-MM-dd'),to_date(min_hist_dt,'yyyy-MM-dd')) >= 6.0 THEN   0            
            ELSE -1
            END
            
            """

flg2_condiiton1 = """
            CASE WHEN to_date(hist_dt1,'yyyy-MM-dd') == to_date(min_hist_dt,'yyyy-MM-dd')  THEN   0            
            ELSE flg2
            END
            
            """

sum_expr = "AGGREGATE(month_diff_list,CAST(0 AS DOUBLE),(c,n) -> IF(c  < 6.0,c+n,n))"


testdf = empDF.withColumn("month_diff",F.months_between("treatment_date","hist_covid_date")) \
                .withColumn("hist_dt1", F.expr(covid_ind)) \
                .withColumn("hist_dt1_lag", F.lag("hist_dt1",1).over(runnigSum)) \
                .withColumn("min_hist_dt", F.min("hist_dt1").over(runnigSum)) \
                .withColumn("flg2", F.expr(flg2_condiiton)) \
                .withColumn("flg2", F.expr(flg2_condiiton1)) \
                .na.fill(-1,["flg2"])

#testdf.printSchema()
testdf.sort("acct_num_key","treatment_date").show()

#else to_date(treatment_date,'yyyy-MM-dd')