import sys

from pyspark.sql import SparkSession
import luigi
from pyspark.sql import functions as F
from pyspark.sql import Window
import snowflake

emp = [('0460_1', 10397, '2020-04-16', 1, '2020-04-01'),
       ('0460_1', 10397, '2020-05-07', 2, '2020-04-01'),
       ('0460_1', 10397, '2020-07-25', 3, '2020-04-01'),
       ('0460_1', 10397, '2020-09-20', 4, '2020-04-01'),
       ('0460_1', 10397, '2020-10-02', 5, '2020-04-01'),
       ('0460_1', 10397, '2020-10-03', 6, '2020-04-01'),
       ('7494_1', 10397, '2020-11-05', 1, '2020-06-01'),
       ('7494_1', 10397, '2020-12-10', 2, '2020-06-01'),
       ('7494_1', 10397, '2021-01-15', 3, '2020-06-01'),
       ('7495_1', 10397, '2020-12-05', 1, '2020-06-01'),
       ('7495_1', 10397, '2021-07-10', 2, '2020-06-01'),
       ('7495_1', 10397, '2022-01-15', 3, '2020-06-01'),
       ('7496_1', 10397, '2020-06-01', 1, '2020-12-05'),
       ('7496_1', 10397, '2021-07-10', 2, '2020-12-05'),
       ('7496_1', 10397, '2022-01-15', 3, '2020-12-05'),
       ('4948_1', 10397, '2020-10-06', 1, '2020-04-01'),
       ('4948_1', 10397, '2021-02-25', 2, '2020-04-01'),
       ('4948_1', 10397, '2021-04-21', 3, '2020-04-01'),
       ]

empcols = ["acct_num_key", "program_id", "treatment_date", "record_number", "hist_covid_date"]

spark = SparkSession \
    .builder \
    .master("local[1]") \
    .appName("pysparkpoc") \
    .enableHiveSupport() \
    .getOrCreate()

# empDF = spark.createDataFrame(data=emp, schema = empcols)

fielname = "C:\\Users\\10679197\\Desktop\\JsonSourceCode\\file"

testDf = spark.read.csv(fielname, header=False, sep=",")

newdf = testDf.withColumn("newcol",F.col("_c0") + F.col("_c9"))

newdf.show()


